<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobState extends Model 
{

    protected $table = 'jobStates';
    public $timestamps = false;
    protected $fillable = array('name');

}