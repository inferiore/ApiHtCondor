{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('realname', 'Realname:') !!}
			{!! Form::text('realname') !!}
		</li>
		<li>
			{!! Form::label('fullPath', 'FullPath:') !!}
			{!! Form::text('fullPath') !!}
		</li>
		<li>
			{!! Form::label('idJob', 'IdJob:') !!}
			{!! Form::text('idJob') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}