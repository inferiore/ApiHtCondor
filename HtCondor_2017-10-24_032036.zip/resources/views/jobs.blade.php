{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('observation', 'Observation:') !!}
			{!! Form::text('observation') !!}
		</li>
		<li>
			{!! Form::label('algorithm', 'Algorithm:') !!}
			{!! Form::text('algorithm') !!}
		</li>
		<li>
			{!! Form::label('outPut', 'OutPut:') !!}
			{!! Form::text('outPut') !!}
		</li>
		<li>
			{!! Form::label('submitCondor', 'SubmitCondor:') !!}
			{!! Form::text('submitCondor') !!}
		</li>
		<li>
			{!! Form::label('idState', 'IdState:') !!}
			{!! Form::text('idState') !!}
		</li>
		<li>
			{!! Form::label('idInsertUser', 'IdInsertUser:') !!}
			{!! Form::text('idInsertUser') !!}
		</li>
		<li>
			{!! Form::label('iteracion', 'Iteracion:') !!}
			{!! Form::text('iteracion') !!}
		</li>
		<li>
			{!! Form::label('idTool', 'IdTool:') !!}
			{!! Form::text('idTool') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}