{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('idTarea', 'IdTarea:') !!}
			{!! Form::text('idTarea') !!}
		</li>
		<li>
			{!! Form::label('path', 'Path:') !!}
			{!! Form::text('path') !!}
		</li>
		<li>
			{!! Form::label('idUsuarioRegistro', 'IdUsuarioRegistro:') !!}
			{!! Form::text('idUsuarioRegistro') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}