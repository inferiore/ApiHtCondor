{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('nombre', 'Nombre:') !!}
			{!! Form::text('nombre') !!}
		</li>
		<li>
			{!! Form::label('descripcion', 'Descripcion:') !!}
			{!! Form::text('descripcion') !!}
		</li>
		<li>
			{!! Form::label('idEstado', 'IdEstado:') !!}
			{!! Form::text('idEstado') !!}
		</li>
		<li>
			{!! Form::label('idUsuarioRegistro', 'IdUsuarioRegistro:') !!}
			{!! Form::text('idUsuarioRegistro') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}