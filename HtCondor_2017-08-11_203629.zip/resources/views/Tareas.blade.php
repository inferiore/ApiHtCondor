{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('idProyecto', 'IdProyecto:') !!}
			{!! Form::text('idProyecto') !!}
		</li>
		<li>
			{!! Form::label('nombre', 'Nombre:') !!}
			{!! Form::text('nombre') !!}
		</li>
		<li>
			{!! Form::label('descripcion', 'Descripcion:') !!}
			{!! Form::text('descripcion') !!}
		</li>
		<li>
			{!! Form::label('path', 'Path:') !!}
			{!! Form::text('path') !!}
		</li>
		<li>
			{!! Form::label('pathResultLog', 'PathResultLog:') !!}
			{!! Form::text('pathResultLog') !!}
		</li>
		<li>
			{!! Form::label('idUsuarioRegistro', 'IdUsuarioRegistro:') !!}
			{!! Form::text('idUsuarioRegistro') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}