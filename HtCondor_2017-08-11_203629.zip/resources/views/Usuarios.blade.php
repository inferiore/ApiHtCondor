{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('nombre', 'Nombre:') !!}
			{!! Form::text('nombre') !!}
		</li>
		<li>
			{!! Form::label('apellido', 'Apellido:') !!}
			{!! Form::text('apellido') !!}
		</li>
		<li>
			{!! Form::label('sApellido', 'SApellido:') !!}
			{!! Form::text('sApellido') !!}
		</li>
		<li>
			{!! Form::label('idRol', 'IdRol:') !!}
			{!! Form::text('idRol') !!}
		</li>
		<li>
			{!! Form::label('codigo', 'Codigo:') !!}
			{!! Form::text('codigo') !!}
		</li>
		<li>
			{!! Form::label('password', 'Password:') !!}
			{!! Form::text('password') !!}
		</li>
		<li>
			{!! Form::label('email', 'Email:') !!}
			{!! Form::text('email') !!}
		</li>
		<li>
			{!! Form::label('remember_token', 'Remember_token:') !!}
			{!! Form::text('remember_token') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}